package library;


public class fictionbook extends book {
    private String genre;

    public fictionbook(String title, String author, String genre) {
    super(title, author);
    this.genre = genre;
    }

    @Override
    public void displayInfo() {
            super.displayInfo();
            System.out.println("Genre: " + genre);
        }
    }

