package library;


public class librarymain {
    public static void main(String[] args) {
        book book1 = new fictionbook("The Hobbit", "J.R.R. Tolkien", "Fantasy");
        book book2 = new NonFictionBook("Brief History of Time", "Stephen Hawking", "Science");

        book1.displayInfo();
        book2.displayInfo();
    }
}

