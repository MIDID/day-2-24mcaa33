package library;

public class book {
    protected String title;
    protected String author;

    public book(String title, String author) {
        this.title = title;
        this.author = author;

    }

    public void displayInfo() {
        System.out.println("Title: " + title + ", Author: " + author);
    }
}
